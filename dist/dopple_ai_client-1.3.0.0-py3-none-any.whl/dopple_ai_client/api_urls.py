
ml_url = "https://ml.dopple.ai/"
site_url = "https://beta.dopple.ai/"
be_url = "https://be.dopple.ai/"

user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:127.0) Gecko/20100101 Firefox/127.0"
