class DoppleResponse:
    def __init__(self, message, timestamp) -> None:
        self.message = message
        self.timestamp = timestamp
