class UserData:
    def __init__(self, email, avatar_url, join_date) -> None:
        self.email = email
        self.avatar_url = avatar_url
        self.join_date = join_date
