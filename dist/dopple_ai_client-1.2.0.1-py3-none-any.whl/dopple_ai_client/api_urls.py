
ml_url = "https://ml.dopple.ai"
api_url = "https://beta.dopple.ai/api"
site_url = "https://beta.dopple.ai"
be_url = "https://be.dopple.ai"

user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2.1 Safari/605.1.15"
