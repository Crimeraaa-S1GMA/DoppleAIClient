class DoppleBot:
    def __init__(self, dopple_id, display_name, tagline, bio, greeting, avatar_url, banner_url, banner_video_url) -> None:
        self.dopple_id = dopple_id
        self.display_name = display_name
        self.tagline = tagline
        self.bio = bio
        self.greeting = greeting
        self.avatar_url = avatar_url
        self.banner_url = banner_url
        self.banner_video_url = banner_video_url
